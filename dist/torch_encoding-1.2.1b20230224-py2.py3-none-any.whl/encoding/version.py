"""This is encoding version file."""
__version__ = '1.2.1b20230224'
